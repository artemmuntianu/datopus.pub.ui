export const series = {
    tickets: [
        25, 66, 41, 59, 25, 44, 12, 36, 9, 21
    ],
    dates: [
        "10 Mar 2024",
        "11 Mar 2024",
        "12 Mar 2024",
        "13 Mar 2024",
        "14 Mar 2024",
        "15 Mar 2024",
        "16 Mar 2024",
        "17 Mar 2024",
        "18 Mar 2024",
        "19 Mar 2024"
    ]
};