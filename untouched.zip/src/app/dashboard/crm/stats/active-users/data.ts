export const series = {
    users: [
        2300,
        2000,
        2122,
        1988
    ],
    dates: [
        "10 Mar 2024",
        "11 Mar 2024",
        "12 Mar 2024",
        "13 Mar 2024"
    ]
};