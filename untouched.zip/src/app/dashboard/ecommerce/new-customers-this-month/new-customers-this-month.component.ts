import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { RouterLink } from '@angular/router';
import { CustomizerSettingsService } from '../../../customizer-settings/customizer-settings.service';

@Component({
    selector: 'app-new-customers-this-month',
    standalone: true,
    imports: [MatCardModule, RouterLink],
    templateUrl: './new-customers-this-month.component.html',
    styleUrl: './new-customers-this-month.component.scss'
})
export class NewCustomersThisMonthComponent {

    // isToggled
    isToggled = false;

    constructor(
        public themeService: CustomizerSettingsService
    ) {
        this.themeService.isToggled$.subscribe(isToggled => {
            this.isToggled = isToggled;
        });
    }

}