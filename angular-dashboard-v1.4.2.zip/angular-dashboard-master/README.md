# Angular Material Dashboard

This is a customizable Angular Dashboard - built with Angular 19 and Angular Material 19 using Material Design 3.

Version: 1.4.2

Features of the dashboard:

- Authentication using Firebase Auth, Firestore and Storage
- TailwindCSS integrated for utility-CSS styling!
- Dynamically add and remove widgets to the dashboard with drag and drop panel
- Reposition widgets by drag and drop
- Resize the widget height and width using the options panel
- Changes in layout are animated nicely using View Transition API + animate css grid package as fallback
- Dashboard layouts once setup are automatically synced with local storage
- Includes sample widgets for showing statistics, graphs using chart.js and other relevant widgets such as a comments list.
- This app also includes the nested sidebar I've built previously in another series of YouTube tutorials and all of the routes are lazily loaded - for best performance!

## Installation

To install this project, run:

```bash
npm install
```

## Setting up the Firebase Project (required for authentication flow)

This guide covers setting up a new Firebase project and configuring authentication for your Angular dashboard.

## Creating a Firebase Project

1. Go to the Firebase Console: `console.firebase.google.com`
2. Click "Create Project" or "Add Project"
3. Enter a project name
4. Click "Create Project"

## Setting Up Required Services

### Enable Authentication

1. In the Firebase Console, click "Authentication" in the left sidebar
2. Click "Get Started"
3. Under "Sign-in methods", click "Email/Password"
4. Toggle "Enable" for Email/Password authentication
5. Click "Save"

### Enable Firestore Database

1. In the left sidebar, click "Firestore Database"
2. Click "Create Database"
3. "Start in test mode" (for testing or production mode if needed)
4. Select a database location closest to your users
5. Click "Enable"

### Enable Storage (Optional - for profile images)

1. In the left sidebar, click "Storage"
2. Click "Get Started"
3. Choose your security rules configuration
4. Select a storage location
5. Click "Done"

## Getting Firebase Configuration

1. Click the gear icon (⚙️) next to "Project Overview" in the left sidebar
2. Select "Project settings"
3. Scroll down to "Your apps"
4. Click the web icon (</>)
5. Register your app:
   - Enter an app nickname
   - Click "Register app"
6. Copy the Firebase configuration object that looks like this to the `firebase.service.ts` file of the Angular dashboard:

```javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-domain",
  projectId: "your-project-id",
  storageBucket: "your-bucket",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id",
};
```

This file ensures your dashboard can connect to your specific Firebase project.

## Setting Up Test Users

1. Go back to "Authentication" in the left sidebar
2. Click "Users" tab
3. Click "Add User"
4. Enter email and password for test user
5. Click "Add User"
6. Repeat for additional test users

## Creating User Data in Firestore

1. Go to "Firestore Database" in the left sidebar
2. Click "Start collection"
3. Name the collection "users"
4. Add a document:
   - Use the user's UID from Authentication as the document ID
   - Add fields:
     ```
     name: "User Name"
     email: "user@example.com"
     photoURL: "https://..." (optional)
     role: "admin" or "user"
     ```
5. Click "Save"
6. Repeat for additional users

This completes the Firebase Console setup. You now have:

- A Firebase project
- Authentication enabled with email/password
- Firestore Database ready for user data
- Test users created
- Firebase configuration ready to use in your application

Remember to keep your Firebase configuration secure and never commit it directly to version control.
