import { inject, Injectable, signal } from '@angular/core';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  User as FirebaseUser,
  Unsubscribe,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { User } from '../models/user';
import { FirebaseService } from './firebase.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user = signal<User | null>(null);

  firebaseService = inject(FirebaseService);
  auth = this.firebaseService.auth;
  db = this.firebaseService.db;

  unsubscribe: Unsubscribe | null = null;

  constructor() {
    this.unsubscribe = onAuthStateChanged(
      this.firebaseService.auth,
      async (user) => {
        if (!user) {
          this.user.set(null);
          return;
        }

        const userInfo = await this.getUserInfo(user?.uid);
        this.user.set(userInfo);
      }
    );
  }

  async getAuthState(): Promise<FirebaseUser | null> {
    await this.auth.authStateReady();
    return Promise.resolve(this.auth.currentUser);
  }

  login(email: string, password: string) {
    return signInWithEmailAndPassword(this.auth, email, password);
  }

  logout() {
    return this.auth.signOut();
  }

  async getUserInfo(uid: string): Promise<User | null> {
    const userRef = doc(this.db, 'users', uid);
    const userDoc = await getDoc(userRef);

    if (!userDoc.exists()) {
      return null;
    }

    return userDoc.data() as User;
  }

  ngOnDestroy() {
    this.unsubscribe?.();
  }
}
