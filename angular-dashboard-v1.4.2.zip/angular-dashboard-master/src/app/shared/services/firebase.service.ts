import { Injectable, signal } from "@angular/core";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  User as FirebaseUser,
} from "firebase/auth";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import { User } from "../models/user";

const firebaseConfig = {
  // Add your firebase config
};

@Injectable({
  providedIn: "root",
})
export class FirebaseService {
  app = initializeApp(firebaseConfig);
  auth = getAuth(this.app);
  db = getFirestore(this.app);
}
