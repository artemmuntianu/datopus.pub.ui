import { Component } from '@angular/core';

@Component({
    selector: 'app-comments',
    imports: [],
    template: ``,
    styles: []
})
export default class CommentsComponent {}
